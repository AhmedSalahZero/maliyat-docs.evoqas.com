<?php

namespace App\Http\Requests\App;

use App\Http\Requests\Concerns\GuardsDocumentTotal;
use App\Http\Requests\Concerns\GuardsStockLevels;
use App\Support\FinancialRules;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

// ══════════════════════════════════════════════════════════════════
//  Maliyat Docs — StoreSaleRequest
//  Location: app/Http/Requests/App/StoreSaleRequest.php
//  Used by App\Http\Controllers\App\SaleController::store()
//
//  "Sell to {customer}: {lines...} for {total}, paid {mode}."
// ══════════════════════════════════════════════════════════════════
class StoreSaleRequest extends FormRequest
{
    use GuardsDocumentTotal, GuardsStockLevels;

    public function authorize(): bool
    {
        return (bool) $this->user()?->company_id;
    }

    public function rules(): array
    {
        $companyId = $this->user()->company_id;

        return [
            'customer_id' => [
                'required',
                Rule::exists('customers', 'id')->where('company_id', $companyId),
            ],
            'date' => ['required', ...FinancialRules::date()],

            'lines'              => ['required', 'array', 'min:1'],
            'lines.*.item_id'    => ['nullable', Rule::exists('items', 'id')->where('company_id', $companyId)],
            'lines.*.qty'        => ['required', ...FinancialRules::qty()],
            'lines.*.unit_price' => ['required', ...FinancialRules::amount(0)],

            'vat_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],

            'mode'       => ['required', Rule::in(['now', 'later', 'partial', 'installment'])],
            'method'     => ['nullable', Rule::in(['cash', 'bank', 'visa', 'instapay', 'wallet'])],
            'payment_channel_id' => ['nullable', Rule::exists('payment_channels', 'id')->where('company_id', $companyId)],
            'amount_now' => ['required_if:mode,partial', 'nullable', ...FinancialRules::amount()],
            'due_date'   => ['nullable', 'date', 'after_or_equal:date', 'before_or_equal:'.FinancialRules::latestAllowedDueDate()],
            'due_in_days'=> ['nullable', 'integer', 'min:1', 'max:365'],

            // Only used when mode = 'installment' — see
            // PaymentRecorderService::buildInstallmentSchedule().
            'installment_count'         => ['required_if:mode,installment', 'nullable', 'integer', 'min:2', 'max:60'],
            'installment_interval_days' => ['required_if:mode,installment', 'nullable', 'integer', 'min:1', 'max:365'],
        ];
    }

    /**
     * Checks that need the lines added up first — see
     * GuardsDocumentTotal.
     */
    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            if ($validator->errors()->isNotEmpty()) {
                return;
            }

            $subtotal = $this->documentLineTotal();
            $this->rejectTotalAboveCeiling($validator, $subtotal);

            $vatRate = (float) ($this->input('vat_rate') ?? 0);
            $total   = round($subtotal + round($subtotal * $vatRate / 100, 2), 2);
            $this->rejectAmountNowAboveTotal($validator, $total);

            // Last, so a line already rejected for a bad quantity is
            // not also told it is out of stock.
            $this->rejectOversellingStock($validator, null);
        });
    }
}
