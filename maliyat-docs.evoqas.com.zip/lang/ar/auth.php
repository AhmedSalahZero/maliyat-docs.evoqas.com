<?php

return [
    'login'                => 'تسجيل الدخول',
    'logout'               => 'تسجيل الخروج',
    'register'             => 'إنشاء حساب',
    'email'                => 'البريد الإلكتروني',
    'password'             => 'كلمة المرور',
    'password_confirm'     => 'تأكيد كلمة المرور',
    'remember_me'          => 'تذكرني',
    'forgot_password'      => 'نسيت كلمة المرور؟',
    'reset_password'       => 'إعادة تعيين كلمة المرور',
    'send_reset_link'      => 'إرسال رابط الاستعادة',
    'already_registered'   => 'لديك حساب بالفعل؟',
    'no_account'           => 'ليس لديك حساب؟',

    // ── Registration ──────────────────────────────────────────
    'full_name'            => 'الاسم الكامل',
    'nickname'             => 'الاسم المستعار',
    'nickname_hint'        => 'هذا هو اسمك العام. يظهر في المنتدى والحالات والوثائق بدلاً من اسمك الحقيقي.',
    'nickname_placeholder' => 'مثال: خبير_مالي، محترف_تسويق',
    'profession'           => 'مهنتك',
    'experience_level'     => 'مستوى الخبرة',
    'select_hub'           => 'اختر مجموعتك',
    'select_hub_hint'      => 'اختر المجالات المهنية التي تريد الانضمام إليها. يمكنك الانضمام لأكثر من مجموعة.',
    'language_preference'  => 'اللغة المفضلة',

    // ── Verification ──────────────────────────────────────────
    'verify_email'         => 'تحقق من البريد الإلكتروني',
    'verify_email_sent'    => 'تم إرسال رابط التحقق إلى بريدك الإلكتروني.',
    'verify_email_check'   => 'قبل المتابعة، يرجى التحقق من بريدك الإلكتروني للحصول على رابط التحقق.',
    'verify_resend'        => 'إعادة إرسال بريد التحقق',
    'verify_resend_sent'   => 'تم إرسال رابط تحقق جديد إلى بريدك الإلكتروني.',

    // ── Account Status ────────────────────────────────────────
    'account_suspended'    => 'تم تعليق حسابك. يرجى التواصل مع الدعم.',
    'account_inactive'     => 'حسابك غير نشط. يرجى التواصل مع الدعم.',

    // ── Failed Messages ───────────────────────────────────────
    'blocked_submission' => 'تعذّر إرسال النموذج. يرجى تحديث الصفحة والمحاولة مرة أخرى.',

    'failed'               => 'بيانات الاعتماد هذه لا تطابق سجلاتنا.',
    // Used for ANY throttled auth route, not just sign-in — see the
    // ThrottleRequestsException handler in bootstrap/app.php.
    'throttle_requests' => 'محاولات كثيرة جداً. يرجى الانتظار :seconds ثانية ثم المحاولة مرة أخرى.',

    'throttle'             => 'محاولات تسجيل دخول كثيرة جداً. يرجى المحاولة مرة أخرى بعد :seconds ثانية.',
    'password_incorrect'   => 'كلمة المرور المدخلة غير صحيحة.',

    // ── Password Reset ────────────────────────────────────────
    'reset_link_sent'      => 'لقد أرسلنا رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.',
    'password_reset_done'  => 'تم إعادة تعيين كلمة المرور بنجاح.',
    'new_password'         => 'كلمة المرور الجديدة',
    'confirm_new_password' => 'تأكيد كلمة المرور الجديدة',
    'reset_email_not_found' => 'لم نجد حسابًا مرتبطًا بهذا البريد الإلكتروني.',
    // Shown when the two password boxes disagree. It used to read
    // "Password confirmed." — the message for the OPPOSITE outcome,
    // so somebody who mistyped their confirmation was told they had
    // succeeded while the form refused to submit.
    'password_confirmed'    => 'كلمتا المرور غير متطابقتين.',

    // ── Verification Codes (OTP) ──────────────────────────────
    // مستخدمة في EmailVerificationService وشاشات التحقق.
    'registration_complete'        => 'تم إنشاء حسابك. أدخل الرمز المُرسل إلى بريدك لإكمال تسجيل الدخول.',
    'verification_code_invalid'    => 'الرمز غير صحيح. يرجى مراجعته والمحاولة مرة أخرى.',
    'verification_code_expired'    => 'انتهت صلاحية الرمز. اطلب رمزًا جديدًا للمتابعة.',
    'verification_code_locked'     => 'عدد محاولات خاطئة كبير. اطلب رمزًا جديدًا للمتابعة.',
    'verification_already_verified' => 'هذا البريد الإلكتروني مُفعّل بالفعل. يمكنك تسجيل الدخول مباشرة.',
    'verification_email_not_found' => 'لم نجد حسابًا بانتظار التفعيل بهذا البريد الإلكتروني.',
];
